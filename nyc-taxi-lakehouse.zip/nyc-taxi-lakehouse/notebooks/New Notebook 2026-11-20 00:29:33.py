# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

# COMMAND ----------

SRC_DIR   = "/Volumes/taxi_project/bronze/data/"
TRIPS_TBL = "taxi_project.bronze.yellow_trips"
LOG_TBL   = "taxi_project.bronze.ingestion_log"

# COMMAND ----------

data = for t in dbutils.fs.ls('/Volumes/taxi_project/bronze/data'):
    {t}

ingestion_log = spark.createDataFrame([], "source_file STRING, file_size INT, row_count INT, ingested_at TIMESTAMP, status STRING")

# COMMAND ----------

dbutils.fs.ls('/Volumes/taxi_project/bronze/data')

# COMMAND ----------

ingestion_log.write.mode("append").saveAsTable("ingestion_log")